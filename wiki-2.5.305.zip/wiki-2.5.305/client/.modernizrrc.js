module.exports = {
  classPrefix: 'mdz-',
  options: ['setClasses'],
  'feature-detects': [
    'css/backdropfilter'
  ]
}
