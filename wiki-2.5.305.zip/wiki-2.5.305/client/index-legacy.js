require('./scss/legacy.scss')
require('./scss/fonts/default.scss')

window.WIKI = null
